package compiler.phase3;

public enum AccessModifier {
    PRIVATE,
    PUBLIC
}
