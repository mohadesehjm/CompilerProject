package compiler.phase3;

public enum Type {
    INT,
    STRING,
    BOOL,
    CLASS
}